package bai_2;

public class HinhVuong extends HinhChuNhat {
    public HinhVuong(int a) {
        super();
        chieuDai = chieuRong = a;
    }
}
