package bai_5;

public class Hinh {
//Em không hiểu đề bài 5
}
